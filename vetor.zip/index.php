<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  <?php
      $alunos = ["luis", "vermeio", "klein"];
  
      echo "<pre>";
      echo var_dump($alunos);
      echo "<br>";
      print_r($alunos);

      $cliente = ["gabriel", 39, 1.92, true];
      print_r($cliente);
      var_dump($cliente);
      echo $cliente[0];
      $cursos = [];
      print_r ($cursos);

  $cursos[0]= "des sistemas";
  $cursos[1]= "informatica";
   $cursos[4]= "eletro";

  echo "<h1> funcoes para vetores</h1> <br>";
  echo "escrevendo depois da array push <br>";
  array_push($alunos, "luiza", "erik");
  print_r($alunos);

  echo "adicionando antes array unshift<br>";
  array_unshift($alunos, "andre", "eduardo");
  print_r($alunos);

  echo "apagando o ultimo indice do vetor";
  array_pop($alunos);
  print_r($alunos);

  echo "apagando o primeiro indice do vetor";
  array_shift($alunos);
  print_r($alunos);

  echo "cotando os elementos <br>";
  echo count($alunos);
  $qtd_alunos = count($alunos);
  echo "<br> qtd de alunos: $qtd_alunos <br><br>";

  echo "ordenando menor para o maior <br>";
    rsort($alunos);
  print_r($alunos);
  
  echo "</pre>";

  $qtd_alunos = count($alunos);
  
  for ($i = 0; $i < $qtd_alunos; $i++){
    echo "$alunos[$i] <br>";
  }
  echo "<br>-----<br>";
  foreach ($alunos as $indice => $aluno){
    echo "$indice : $aluno <br>";
  }
      ?>
</body>
</html>